<?php
require("constants.php");
// $connection = mysql_connect( DB_SERVER, DB_USER, DB_PASS );
// if( !$connection ) {
// 	die( "Database connection failed: " . mysql_error() );
// }
// // 2. Select a database to use
// $db_select = mysql_select_db( DB_NAME, $connection );
// if( !$db_select ) {
// 	die( "Database selection failed: " . mysql_error() );
// }

//Create a database connection
			$dbhost = DB_SERVER;
			$dbuser = DB_USER;
			$dbpass = DB_PASS;
			$dbname = DB_NAME;
			$connection = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);

			//Test if connection failed
			if(mysqli_connect_errno()){
				die("Database connection failed: ".mysqli_connect_error()." (".mysqli_connect_errno(). " )");
			}


?>



