<?php 
	require_once("includes/functions.php");
	require_once("includes/connection.php"); 
?>
<html>
	<head>
		  <link rel="stylesheet" type="text/css" href="/css/style.css">
	</head>		  

<body>
	<div>
		<div id="img">	<img src = "/images/1.png"> </img> </div> 
			<div id="navbar">
				<ul>
				  <li><a href="home.php">Home</a></li>
				  <li><a href="user_register.php">Register</a></li>
				  <li><a href="user_login.php">Student Login</a></li>
				  <li><a href="admin_login.php">Admin Login</a></li>
				</ul>
			</div>
	</div>	
		<br><br>

	<?php	
		if($_POST)
		{
			// Perform query
			$username = $_POST['first_name'];
			$lastname = $_POST['last_name'];
			$address = $_POST['address'];
			$email = $_POST['email'];
			$password = $_POST['pass'];
			$mobile = $_POST['mobile'];
			$birthdate = $_POST['date'];
			$gender = $_POST['gender'];
			$nationality = $_POST['nation'];

				
			$check=mysqli_query($connection,"select * from admins_info where email='$email'");
 		    $checkrows=mysqli_num_rows($check);

 		    if($checkrows>0) {
			      echo "<h2>User with same Email already exists.Try again with a different Email</h2>";
			   } else {  
			 $query = "
		  		INSERT INTO `admins_info` (`firstname`, `lastname`, `address`, `email`,
		        `password`, `mobile`, `birthday`,`gender`,`nation`) VALUES ('$username',
		        '$lastname', '$address', '$email',
		        '$password','$mobile', '$birthdate','$gender','$nationality');";
			$result = mysqli_query($connection,$query);

			if(!$result){
				die("<b><b>Registration Failed.</b></b>");
			}
			else{
				echo "<h2> Registration Successful</h2>";
				echo "<h2> You can now Login</h2>";
			}
		}
		
			// Close the database connection
			mysqli_close($connection);
		}
	?>	

</body>

</html>